<?php

/**
 * tmcTwitterBootstrapPlugin configuration.
 *
 * @package     tmcTwitterBootstrapPlugin
 * @subpackage  components
 * @author      Tito Miguel Costa <symfony@titomiguelcosta.com>
 */
require_once dirname(__FILE__) . '/../lib/BaseTmcTwitterBootstrapComponents.class.php';

class tmcTwitterBootstrapComponents extends BaseTmcTwitterBootstrapComponents
{

}