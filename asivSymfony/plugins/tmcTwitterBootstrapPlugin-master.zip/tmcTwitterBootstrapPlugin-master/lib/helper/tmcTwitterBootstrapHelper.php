<?php

/**
 * tmcTwitterBootstrapPlugin configuration.
 *
 * @package     tmcTwitterBootstrapPlugin
 * @subpackage  helper
 * @author      Tito Miguel Costa <symfony@titomiguelcosta.com>
 */