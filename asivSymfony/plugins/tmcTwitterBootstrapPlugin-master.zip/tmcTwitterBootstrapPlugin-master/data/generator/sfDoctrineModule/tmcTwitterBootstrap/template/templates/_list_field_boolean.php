[?php if ($value): ?]
  <i class="icon-ok"></i>
[?php else: ?]
  <i class="icon-remove"></i>
[?php endif; ?]