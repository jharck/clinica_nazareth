<div class="span2">
    <div class="sidebar-nav">
        <div class="sidebar-inner">
            <div class="well">
                <h3>[?php echo <?php echo $this->getI18NString('show.title') ?> ?]</h3>
            </div>
        </div>
    </div>
</div>
