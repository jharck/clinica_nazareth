<div class="sidebar">
    <div class="sidebar-inner">
        <div class="well">
            <p>[?php echo __('Sidebar text', null, 'tmcTwitterBootstrapPlugin') ?]</p>
        </div>
    </div>

    <div class="sidebar-expander togglesidebar well">
        <p><small>&gt;</small></p>
    </div>
</div>